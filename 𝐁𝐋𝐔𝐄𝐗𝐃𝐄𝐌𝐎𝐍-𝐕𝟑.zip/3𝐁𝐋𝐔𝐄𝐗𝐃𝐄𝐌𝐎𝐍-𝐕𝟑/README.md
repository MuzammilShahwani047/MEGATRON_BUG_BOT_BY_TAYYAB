[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=600&size=25&pause=1000&width=435&lines=THANK+FOR+VISITING+MY+REPO)](https://git.io/typing-svg)

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=&weight=608&pause=1000&color=F7A546&width=435&lines=FORK+AND+STAR+THIS+REPOSITORY+)](https://git.io/typing-svg)


<a href="https://whatsapp.com/channel/0029Vah3fKtCnA7oMPTPJm1h">
  <img alt="DEMON-BUG-V3" height="300" src="https://l.top4top.io/p_32188bbq00.jpg">
</a>
</p>
  <div align="center">
  <img src="https://spogit.vercel.app/api?theme=dark&rainbow=true&scan=true" alt="Widget with the current Spotify song"  />
</div>


---


 # SET-UP

 # Fork

<h4 align="center">   

- *You MUST `fork` Fork this repo by tapping  [`here`](https://github.com/BLUEXDEMONl/BLUEXDEMON-BUG-V3/fork)***

*star✨ my repo if you like this bot🤖**


## DEPLOY....🔥🎯



***Tap the WhatsApp logo below to join our channel and group for updates***

<p align="left">
  <a aria-label="Join our channel for updates" href="https://whatsapp.com/channel/0029Vah3fKtCnA7oMPTPJm1h" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/CHANNEL-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>

<p align="left">
  <a aria-label="Join our group for updates" href="https://whatsapp.com/channel/0029Vah3fKtCnA7oMPTPJm1h" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/WA GROUP-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>


Incase of any issues, contact me  [here](https://wa.me/2347041039367) via WhatsApp.

Modifying the bot structure is at your own risk. We won't offer technical support if error occur.


## License

[MIT License](https://github.com/BLUEXDEMONl/BLUEXDEMON-BUG-V3/blob/main/LICENSE)

HEHE

CREDITS; BLUE DEMON,ZNY❤️‍🩹❤️‍🩹
